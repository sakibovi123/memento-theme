<?php include 'header.php'; ?>

<?php include 'pages/home/components/home-solution-2.php';?>
<?php include 'pages/home/components/about-company.php'; ?>
<?php include 'pages/home/components/home-service.php';?>
<?php include 'pages/home/components/home-testimonials.php'; ?>
<?php include 'pages/home/components/our-complete-craft.php'; ?>

<?php 'footer.php' ?>